import os
import shutil
import random
from pathlib import Path

def create_split_directories():
    """创建分割后的数据集目录结构"""
    base_dir = Path("hash_dataset_split")
    splits = ["train", "val", "test"]
    
    for split in splits:
        split_dir = base_dir / split
        split_dir.mkdir(parents=True, exist_ok=True)
    
    return base_dir

def split_dataset(source_dir="hash_dataset", train_ratio=0.7, val_ratio=0.2, test_ratio=0.1):
    """
    将数据集分割为训练集、验证集和测试集
    
    参数:
        source_dir (str): 源数据目录
        train_ratio (float): 训练集比例
        val_ratio (float): 验证集比例
        test_ratio (float): 测试集比例
    """
    # 确保比例之和为1
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6, "比例之和必须为1"
    
    # 创建目标目录
    base_dir = create_split_directories()
    
    # 获取所有文件
    source_path = Path(source_dir)
    all_files = list(source_path.glob("*"))
    
    # 随机打乱文件列表
    random.shuffle(all_files)
    
    # 计算每个集合的大小
    total_files = len(all_files)
    train_size = int(total_files * train_ratio)
    val_size = int(total_files * val_ratio)
    
    # 分割数据集
    train_files = all_files[:train_size]
    val_files = all_files[train_size:train_size + val_size]
    test_files = all_files[train_size + val_size:]
    
    # 复制文件到对应目录
    for files, split_name in [(train_files, "train"), 
                            (val_files, "val"), 
                            (test_files, "test")]:
        for file in files:
            dest_path = base_dir / split_name / file.name
            shutil.copy2(file, dest_path)
    
    # 打印统计信息
    print(f"数据集分割完成:")
    print(f"总文件数: {total_files}")
    print(f"训练集: {len(train_files)} 文件")
    print(f"验证集: {len(val_files)} 文件")
    print(f"测试集: {len(test_files)} 文件")

if __name__ == "__main__":
    # 设置随机种子以确保可重复性
    random.seed(42)
    
    # 执行数据集分割
    split_dataset() 