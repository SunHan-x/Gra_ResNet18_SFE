# Patch Dataset

## 项目结构

```
.
├── hash_dataset/         # 原始哈希数据集
└── hash_dataset_split/   # 分割后的哈希数据集
```

## 目录说明

- `hash_dataset/`: 存放原始patch数据集的目录
- `hash_dataset_split/`: 存放经过分割处理后的数据集目录